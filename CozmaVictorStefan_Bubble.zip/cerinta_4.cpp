// Parcurgerea sirului de la ultima bula catre prima //

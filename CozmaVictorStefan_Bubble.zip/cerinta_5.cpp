// Parcurgerea sirului numind bula prin index membru drept //
